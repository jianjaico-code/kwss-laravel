@include('inc.header')

    <div id="wrapper">
        <div id="" class="login-container-main">
            @yield('content')
        </div>
        <!-- /#page-wrapper -->
    </div>
@include('inc.footer')